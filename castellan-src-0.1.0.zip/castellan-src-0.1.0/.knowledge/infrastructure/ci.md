---
type: Playbook
title: "Castellan — CI"
description: "The single gate, its caches, and the checks CI cannot perform (with their owners)."
tags:
  - ci
  - quality
status: stable
generated:
  by: agent/castellan-kb
  at: "2026-10-01T22:00:00Z"
updated: "2026-10-01T20:45:00Z"
id: infrastructure/ci
category: infrastructure
refs:
  - infrastructure/monorepo
  - infrastructure/codegen
---
# CI

One job, ordered gates, fast-fail: checkout → rustup + bun (pinned) →
cargo caches (workspace `Cargo.lock` keyed) → `bun install --frozen-lockfile`
→ codegen → `bun run wasm` → `cargo fmt --all --check` → actionlint
(`bun run lint:workflows`) → `bun run lint` → typecheck → docs build →
tests (`cargo test` + `bun test` through turbo) → cargo-deny advisories.
Clippy `-D warnings` runs in the lint task; codegen-then-typecheck means
a stale generated directory fails the build instead of a review.

## What each gate buys

- **clippy -D warnings + missing_docs**: the workspace lints; a PR cannot
  land undocumented public API.
- **cargo test**: example tests, rstest `#[fixture]`/`#[case]` matrices,
  and proptest properties (rstest + proptest are the dev-only test
  frameworks, declared in `[workspace.dependencies]`). Properties cover the
  invariants — framing round-trips, otpauth round-trips, passphrase shape —
  and are the specified shape for the harder promises ahead: the KDBX
  round-trip harness (task-8), sync idempotence (task-27). The TS mirror:
  bun tests with fast-check properties (protocol JSON round-trips, client
  id/error/wire-shape properties) and `createFixture` fixtures — same
  vocabulary, other side of the wire (see [Testing](testing.md)).
- **actionlint**: the workflows are code too; `bun run lint:workflows`
  runs on every push, on a release binary the job installs (convco, the
  other toolchain-binary linter, stays local: the commit-msg hook runs it
  when present, and `convco check` over history needs a full clone CI
  does not fetch).
- **codegen zero-diff**: proves the committed TS matches the Rust — drift
  dies at review time.
- **docs build**: `bun run docs:build` — the Starlight site is a workspace
  member with no typecheck/test tasks of its own, so a build step is what
  proves it.
- **wasm step**: the extension face's dependency exists and compiles.
- **deny**: licenses and advisories.

## What CI cannot check (and who owns it instead)

| Gap | Owner |
| --- | --- |
| Desktop/mobile production vite builds not in CI | e2e covers the dev-server build of both faces and the extension's *built* MV3 (its e2e script chains `wxt build`), but `vite build` output of the apps is still ungated; add when a release artifact matters |
| Tool list duplicated between pixi.toml and ci.yml | CI installs bun/rust/cargo-deny/actionlint directly, pixi is the local env (decision-8) — a tool added to one and not the other drifts silently; whoever touches either file updates both, review checks |
| Tauri app crates (no webkit in CI) | release builds + the task-37 reproducible-build work |
| Mobile on-device behavior (biometrics, providers) | hardware checklists, tasks 23/30/31/32 |
| Extension in real browsers | Playwright suite runs, but store-review quirks are manual |
| HIBP / LocalSend against the live world | integration smoke tests, manual before release |
| cargo-deny databases age between runs | advisories are re-checked on every CI run by design |

Known-limit honesty is a feature: the README's validated-state section
mirrors this table so nobody trusts a gate that does not exist.
