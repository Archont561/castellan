/**
 * Hand-maintained type shim for the wasm-bindgen bundler glue
 * (`castellan_wasm_bg.js`). wasm-pack writes `castellan_wasm.d.ts` for the
 * public entry but nothing for the glue module itself; this shim declares
 * the two things a consumer without bundler wasm-ESM support needs: the
 * wiring function and the public surface it enables.
 *
 * wasm-pack never writes a file with this name, so a rebuild leaves it
 * alone; the .gitignore un-ignores it specifically for that reason.
 */

/** Set the instantiated wasm exports the glue's wrappers call through. */
export function __wbg_set_wasm(exports: object): void;

/** Whether an entry saved at `candidate` should be offered at `origin`. */
export function origin_matches(origin: string, candidate: string): boolean;

/** Parse an otpauth URI (serde-wasm-bindgen value; no secret field). */
export function parse_otpauth(uri: string): any;

/** The protocol version of the shared logic this build was cut from. */
export function protocol_version(): number;
