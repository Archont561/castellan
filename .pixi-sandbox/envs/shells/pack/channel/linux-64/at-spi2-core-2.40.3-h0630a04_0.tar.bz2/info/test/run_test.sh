

set -ex



test -f $PREFIX/include/at-spi-2.0/atspi/atspi.h
test -f $PREFIX/lib/libatspi${SHLIB_EXT}
exit 0
