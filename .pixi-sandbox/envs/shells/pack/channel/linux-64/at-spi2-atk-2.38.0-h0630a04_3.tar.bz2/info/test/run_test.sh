

set -ex



test -f $PREFIX/include/at-spi2-atk/2.0/atk-bridge.h
test -f $PREFIX/lib/libatk-bridge-2.0${SHLIB_EXT}
exit 0
